"""Distribution safety checks."""
